# 部署安装说明

## 📦 部署包内容

本部署包包含了完整的 AI Test Case Generator 项目，可直接部署到新服务器。

## 🚀 快速安装（5分钟）

### 1. 解压文件

将下载的 `.zip` 文件解压到目标目录

```bash
# Windows
unzip testgen-ai-pro-deploy-xxxxxx.zip
# 或使用 7-Zip / WinRAR 解压

# Linux/macOS
unzip testgen-ai-pro-deploy-xxxxxx.zip
cd testgen-ai-pro
```

### 2. 创建虚拟环境（推荐）

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Linux/macOS
python3 -m venv venv
source venv/bin/activate
```

### 3. 安装依赖

```bash
pip install -r requirements.txt
```

### 4. 安装 Playwright 浏览器（网页抓取功能需要）

```bash
playwright install chromium
```

### 5. 配置 API Key

复制 `.env.example` 为 `.env`，并填写对应的 API Key：

```bash
# Windows
copy .env.example .env
# 编辑 .env 文件

# Linux/macOS
cp .env.example .env
# 编辑 .env 文件
```

`.env` 文件配置示例：

```bash
# DeepSeek API（推荐，性价比高）
DEEPSEEK_API_KEY=sk-your-deepseek-api-key-here

# Qwen API（阿里云）
DASHSCOPE_API_KEY=sk-your-qwen-api-key-here

# OpenAI API
OPENAI_API_KEY=sk-your-openai-api-key-here

# Ollama（本地模型，无需 API Key）
# 只需在配置面板选择 Ollama-Local 即可
```

### 6. 启动应用

```bash
streamlit run app.py
```

应用会在浏览器中自动打开，默认地址：`http://localhost:8501`

## 🛠️ 可选配置

### 生产环境部署

如果需要在生产环境中运行，建议：

```bash
# 指定端口和服务器地址
streamlit run app.py --server.port 8501 --server.address 0.0.0.0

# 禁用自动运行
streamlit run app.py --server.headless true
```

### 使用配置文件

创建 `.streamlit/config.toml` 配置文件：

```toml
[server]
port = 8501
address = "0.0.0.0"
headless = true
maxUploadSize = 200

[theme]
primaryColor = "#1E88E5"
backgroundColor = "#FFFFFF"
```

## 🌐 支持的 LLM 模型

| 模型 | 推荐度 | 说明 |
|------|--------|------|
| DeepSeek-V3 | ⭐⭐⭐⭐⭐ | 性价比高，中文支持好 |
| DeepSeek-R1 | ⭐⭐⭐⭐ | 推理能力强 |
| Qwen-Max | ⭐⭐⭐⭐ | 阿里云，支持图片识别 |
| GPT-4V | ⭐⭐⭐⭐ | 多模态，图片识别 |
| Ollama-Local | ⭐⭐⭐ | 本地运行，无需联网 |

## 📚 功能说明

1. **文本输入生成**：直接输入需求描述，生成测试用例
2. **文档上传生成**：上传 Word 文档，解析后生成测试用例
3. **网页抓取生成**：输入网页 URL，自动识别页面元素并生成测试用例
4. **图片识别生成**：上传图片（UI截图），识别后生成测试用例（需多模态模型）

## 🔧 常见问题

### 1. Playwright 安装失败

```bash
# 尝试使用国内镜像
PLAYWRIGHT_DOWNLOAD_HOST=https://npmmirror.com/mirrors/playwright/ playwright install chromium

# 或者安装依赖
playwright install chromium --with-deps
```

### 2. API Key 配置错误

确保 `.env` 文件位于项目根目录，并且格式正确（不要有多余的引号）。

### 3. 中文乱码

确保系统编码为 UTF-8。在 Windows 上，可以在命令行执行：

```bash
chcp 65001
```

### 4. 动态页面抓取失败

- 确认已安装 Playwright 浏览器
- 在网页抓取功能中勾选"动态渲染"
- 增加等待时间

## 📖 详细文档

- 部署文档：`DEPLOY.md`
- 故障排查：`docs/troubleshooting.md`
- 动态抓取安装：`docs/dynamic-scraper-install.md`

## 💡 提示

- 首次使用建议先测试文本输入功能
- 建议使用 DeepSeek-V3，性价比最高
- 网页抓取功能需要网络连接
- 生成后的用例可以在线编辑，支持导出 Excel/Word/Markdown

## 📞 技术支持

如有问题，请查看 `docs/troubleshooting.md` 或联系技术支持。
