# Assets 资源目录

此目录用于存放项目的静态资源文件。

## 文件说明

- `logo.png` - 应用图标（可选）
- `styles.css` - 自定义样式（可选）

## 使用方法

在 app.py 中引用资源：
```python
import streamlit as st

# 显示 logo
st.image("assets/logo.png", width=100)
```
