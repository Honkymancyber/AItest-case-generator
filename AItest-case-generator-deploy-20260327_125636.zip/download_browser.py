"""下载 Chromium 浏览器到项目目录"""
import os
import sys

# 设置浏览器路径到项目目录
project_dir = os.path.dirname(os.path.abspath(__file__))
os.environ['PLAYWRIGHT_BROWSERS_PATH'] = project_dir

print(f"浏览器将下载到: {project_dir}")

# 使用 playwright install 命令
import subprocess
result = subprocess.run([sys.executable, '-m', 'playwright', 'install', 'chromium', '--with-deps'], env=os.environ)
sys.exit(result.returncode)
