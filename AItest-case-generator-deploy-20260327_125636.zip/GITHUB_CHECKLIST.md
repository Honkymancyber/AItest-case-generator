# GitHub 上传前检查清单

## ✅ 项目准备检查

### 核心文件

- [x] `README.md` - 项目说明（已完善）
- [x] `LICENSE` - MIT 许可证（已创建）
- [x] `CONTRIBUTING.md` - 贡献指南（已创建）
- [x] `INSTALL.md` - 安装指南（已创建）
- [x] `requirements.txt` - 依赖列表
- [x] `.gitignore` - Git 忽略配置
- [x] `.env.example` - 环境变量模板

### 代码文件

- [x] `app.py` - 主应用
- [x] `config.py` - 配置文件
- [x] `setup.py` - 安装脚本
- [x] `modules/` - 所有模块
- [x] `utils/` - 工具函数
- [x] `docs/` - 文档

### ⚠️ 需要在 GitHub 上修改的内容

在上传到 GitHub 后，需要手动修改以下内容：

1. **README.md 中的仓库链接**
   ```markdown
   # 当前
   git clone https://github.com/yourname/AItest-case-generator.git

   # 修改为（替换 YOUR_USERNAME）
   git clone https://github.com/YOUR_USERNAME/AItest-case-generator.git
   ```

2. **README.md 中的邮箱地址**
   ```markdown
   # 当前
   - Email: [your-email@example.com]

   # 修改为
   - Email: your-real-email@example.com
   ```

3. **README.md 中的 GitHub Issues 链接**
   ```markdown
   # 修改为你的实际仓库地址
   https://github.com/YOUR_USERNAME/testgen-ai-pro/issues
   ```

## 📦 上传内容总结

### 包含的文件（21个）

```
testgen-ai-pro/
├── README.md                    ✅ 项目说明
├── LICENSE                      ✅ 开源许可证
├── CONTRIBUTING.md             ✅ 贡献指南
├── INSTALL.md                   ✅ 安装指南
├── GITHUB_UPLOAD_GUIDE.md       ✅ GitHub 上传指南
├── GITHUB_CHECKLIST.md          ✅ 上传检查清单
├── DEPLOY.md                   ✅ 部署文档
├── requirements.txt             ✅ 依赖列表
├── setup.py                    ✅ 安装脚本
├── config.py                   ✅ 配置文件
├── app.py                      ✅ 主应用
├── .gitignore                  ✅ Git 忽略配置
├── .env.example                ✅ 环境变量模板
├── modules/
│   ├── __init__.py
│   ├── model_handler.py        ✅ 模型调用
│   ├── case_generator.py      ✅ 用例生成
│   ├── web_scraper.py         ✅ 静态网页抓取
│   ├── web_scraper_dynamic.py ✅ 动态网页抓取
│   ├── exporter.py            ✅ 导出功能
│   └── file_parser.py         ✅ 文件解析
├── utils/
│   ├── __init__.py
│   └── helpers.py             ✅ 辅助函数
├── docs/
│   ├── troubleshooting.md      ✅ 故障排查
│   └── dynamic-scraper-install.md  ✅ 动态抓取安装
└── assets/
    └── README.md              ✅ 资源说明
```

### 不包含的文件（已排除）

- ❌ `.env` - 包含真实 API Key（敏感）
- ❌ `__pycache__/` - Python 缓存
- ❌ `*.pyc` - 编译文件
- ❌ `*.log` - 日志文件
- ❌ `venv/` - 虚拟环境
- ❌ `chromium-1169/` - 浏览器文件（体积大）
- ❌ `chromium_headless_shell-1169/` - 浏览器文件
- ❌ `ffmpeg-1011/` - 媒体文件
- ❌ `winldd-1007/` - Windows 工具
- ❌ `package_project.py` - 打包脚本
- ❌ `testgen-ai-pro-deploy*.zip` - 部署包（可手动上传到 Releases）

## 🚀 GitHub 上传步骤（Web 方式）

### 方法一：使用 GitHub 网页直接上传

如果电脑上没有安装 Git，可以直接通过网页上传：

1. **在 GitHub 创建新仓库**
   - 访问 https://github.com/new
   - Repository name: `testgen-ai-pro`
   - Description: `基于大语言模型的AI测试用例生成工具`
   - 选择 Public
   - 勾选 "Add a README file"（如果想创建空仓库，不要勾选）
   - 勾选 "Choose a license" → 选择 MIT License
   - 点击 "Create repository"

2. **上传文件**
   - 点击仓库页面右上角的 "Add file" → "Upload files"
   - 拖拽或点击选择要上传的文件
   - 建议先上传核心文件：
     - README.md
     - LICENSE
     - requirements.txt
     - app.py
     - config.py
     - modules/ 文件夹（需要先压缩或逐个上传）
   - 在 "Commit changes" 区域填写提交信息
   - 点击 "Commit changes"

3. **创建文件夹**
   - 点击 "Add file" → "Create new file"
   - 输入 `modules/__init__.py` 创建文件
   - 重复此步骤创建所有子文件夹

**注意**：网页上传不适合大量文件，建议安装 Git 使用命令行。

### 方法二：安装 Git 后使用命令行（推荐）

1. **安装 Git**
   - 下载：https://git-scm.com/downloads
   - 安装时选择默认配置即可
   - 安装完成后重新打开命令行

2. **按照 `GITHUB_UPLOAD_GUIDE.md` 中的步骤操作**

## 📊 项目信息

### 仓库元数据建议

```yaml
仓库名: AItest-case-generator
描述: 基于大语言模型的AI测试用例生成工具
标签:
  - ai
  - test-case-generator
  - streamlit
  - llm
  - python
  - testing
  - automation
```

### 首次 Release 信息

```markdown
## v1.0.0 - 首次发布

### 功能特性
- ✅ 支持文本输入生成测试用例
- ✅ 支持 Word 文档解析
- ✅ 支持静态网页抓取
- ✅ 支持动态网页抓取（Playwright）
- ✅ 支持图片识别（多模态模型）
- ✅ 支持多种 LLM（DeepSeek/Qwen/GPT-4V/Ollama）
- ✅ 支持多种导出格式（Excel/Word/Markdown）

### 依赖要求
- Python 3.8+
- Streamlit 1.28+
- OpenAI SDK
- Playwright（可选，用于动态网页抓取）

### 安装
详见 README.md 或 INSTALL.md

### 已知问题
无
```

## 🎯 上传后的优化建议

### 1. 添加 README 截图

在 README.md 中添加应用截图：

```markdown
## 📸 截图

### 主界面
![主界面](docs/screenshots/main.png)

### 文本输入
![文本输入](docs/screenshots/text-input.png)

### 网页抓取
![网页抓取](docs/screenshots/web-scraper.png)

### 导出功能
![导出功能](docs/screenshots/export.png)
```

### 2. 添加 Demo

- 可以在 README 中添加在线 Demo 链接（如果部署了）
- 或者录制操作视频

### 3. 添加 CI/CD

创建 `.github/workflows/test.yml`：

```yaml
name: Test

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Set up Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.8'
      - name: Install dependencies
        run: |
          pip install -r requirements.txt
```

### 4. 添加 Badge 到 README

当前已添加：
- [![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
- [![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
- [![Streamlit](https://img.shields.io/badge/Streamlit-1.28+-red.svg)](https://streamlit.io/)
- [![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

可以添加更多：
```markdown
[![GitHub stars](https://img.shields.io/github/stars/YOUR_USERNAME/testgen-ai-pro)](https://github.com/YOUR_USERNAME/testgen-ai-pro/stargazers)
[![GitHub forks](https://img.shields.io/github/forks/YOUR_USERNAME/testgen-ai-pro)](https://github.com/YOUR_USERNAME/testgen-ai-pro/network/members)
[![GitHub issues](https://img.shields.io/github/issues/YOUR_USERNAME/testgen-ai-pro)](https://github.com/YOUR_USERNAME/testgen-ai-pro/issues)
```

## 📞 需要帮助？

如果在上传过程中遇到问题，可以：

1. 查看 [GitHub 官方文档](https://docs.github.com/)
2. 查看本项目 `docs/troubleshooting.md`
3. 在 GitHub 上创建 Issue 询问

---

**准备就绪！可以开始上传到 GitHub 了！** 🎉
