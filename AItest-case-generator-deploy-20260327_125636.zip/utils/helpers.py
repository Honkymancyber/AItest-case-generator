import re
from datetime import datetime
from urllib.parse import urlparse


def format_timestamp():
    """格式化时间戳"""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def validate_url(url: str) -> bool:
    """验证URL格式"""
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except:
        return False


def clean_text(text: str) -> str:
    """清理文本"""
    return re.sub(r'\s+', ' ', text).strip()
