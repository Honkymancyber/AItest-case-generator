# 部署说明

## 部署包内容

项目已打包为 `AItest-case-generator-deploy.zip`

## 系统要求

- Python 3.8 或更高版本
- Windows / Linux / macOS
- 网络连接（用于安装依赖和下载浏览器）

## 部署步骤

### 1. 解压文件

将 `testgen-ai-pro-deploy.zip` 解压到目标目录

### 2. 创建虚拟环境

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Linux/macOS
python3 -m venv venv
source venv/bin/activate
```

### 3. 安装依赖

```bash
pip install -r requirements.txt
```

### 4. 安装 Playwright 浏览器

```bash
playwright install chromium
```

### 5. 配置 API Key

复制 `.env.example` 为 `.env`，并填写所需的 API Key：

```bash
# Windows
copy .env.example .env

# Linux/macOS
cp .env.example .env
```

编辑 `.env` 文件，根据需要配置以下 API Key：

```
# DeepSeek API（推荐）
DEEPSEEK_API_KEY=your_deepseek_api_key_here

# OpenAI API
OPENAI_API_KEY=your_openai_api_key_here

# Ollama（本地模型，无需 API Key）
# OLLAMA_BASE_URL=http://localhost:11434

# 其他模型...
```

### 6. 启动应用

```bash
streamlit run app.py
```

应用会在浏览器中自动打开，默认地址：`http://localhost:8501`

## 支持的 LLM 模型

- DeepSeek（推荐，性价比高）
- OpenAI (GPT-3.5/4)
- Ollama（本地运行，无需联网）
- Zhipu AI
- Moonshot AI

## 功能说明

1. **文本输入生成**：直接输入需求描述，生成测试用例
2. **文件解析**：上传需求文档（TXT、PDF 等），解析后生成测试用例
3. **网页抓取**：输入网页 URL，自动识别页面元素并生成测试用例

## 常见问题

### 1. 浏览器下载失败

如果 `playwright install chromium` 失败，尝试：

```bash
playwright install chromium --with-deps
```

### 2. API Key 错误

确保 `.env` 文件正确配置，并且 Key 有效。使用前可以先在 LLM 提供商官网验证 Key。

### 3. 中文乱码

确保系统编码为 UTF-8，如果仍有问题，可以在代码中添加编码设置。

### 4. 动态页面抓取失败

如果网页需要 JavaScript 渲染，请勾选"动态渲染"选项。如果仍然失败，可能是页面需要登录或有反爬虫机制。

## 技术支持

如有问题，请查看 `docs/troubleshooting.md` 文件。
