# modules/web_scraper.py
import requests
from bs4 import BeautifulSoup
from typing import Dict, List

class WebScraper:
    """网页抓取器"""
    
    def fetch_page(self, url: str) -> str:
        """抓取网页内容"""
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()

            # 自动检测并使用正确的编码
            if response.encoding is None or response.encoding == 'ISO-8859-1':
                response.encoding = response.apparent_encoding

            return response.text
        except Exception as e:
            raise Exception(f"网页抓取失败: {str(e)}")
    
    def extract_form_elements(self, html_content: str) -> List[Dict]:
        """提取表单元素 - 只保留类型和显示文本"""
        soup = BeautifulSoup(html_content, 'html.parser')
        elements = []

        # 提取所有 input 元素，根据 type 分类
        for input_tag in soup.find_all('input'):
            input_type = input_tag.get('type', 'text')

            if input_type == 'text' or input_type == 'password' or input_type == 'email' or input_type == '':
                # 文本输入框
                text = input_tag.get('placeholder', '') or input_tag.get('value', '')
                elements.append({
                    'type': 'input',
                    'text': text
                })
            elif input_type == 'checkbox':
                # 复选框
                elements.append({
                    'type': 'checkbox',
                    'text': ''
                })
            elif input_type == 'radio':
                # 单选按钮
                text = input_tag.get('value', '')
                elements.append({
                    'type': 'radio',
                    'text': text
                })
            elif input_type == 'submit' or input_type == 'button':
                # 提交按钮
                text = input_tag.get('value', '') or input_tag.get('placeholder', '')
                elements.append({
                    'type': 'button',
                    'text': text
                })

        # 提取文本域
        for textarea_tag in soup.find_all('textarea'):
            text = textarea_tag.get('placeholder', '')
            elements.append({
                'type': 'textarea',
                'text': text
            })

        # 提取下拉选择框（取第一个option的文本）
        for select_tag in soup.find_all('select'):
            first_option = select_tag.find('option')
            text = first_option.get_text(strip=True) if first_option else ''
            elements.append({
                'type': 'select',
                'text': text
            })

        # 提取按钮（如登录、提交等）
        for button_tag in soup.find_all('button'):
            text = button_tag.get_text(strip=True)
            if text:
                elements.append({
                    'type': 'button',
                    'text': text
                })

        # 提取表单标签（如"账号"、"密码"等文字说明）
        for label_tag in soup.find_all('label'):
            text = label_tag.get_text(strip=True)
            if text:
                elements.append({
                    'type': 'label',
                    'text': text
                })

        return elements