# modules/case_generator.py
from typing import List, Dict
from modules.model_handler import ModelHandler

class CaseGenerator:
    """测试用例生成器"""
    
    def __init__(self, model_handler: ModelHandler):
        self.model = model_handler
    
    def analyze_test_points(self, content: str) -> List[str]:
        """分析测试点"""
        return self.model.analyze_test_points(content)
    
    def generate_cases(self, test_points: List[str], requirement: str) -> List[Dict]:
        """生成测试用例"""
        return self.model.generate_test_cases(test_points, requirement)
    
    def generate_cases_from_image(self, image_description: str) -> List[Dict]:
        """从图片描述生成用例"""
        return self.generate_cases([image_description], image_description)