# modules/web_scraper_dynamic.py
"""支持动态渲染的网页抓取器（使用 Playwright 同步 API）"""
from typing import Dict, List, Optional, Tuple
import json
import os
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
import asyncio
import sys

# 设置 Playwright 浏览器驱动路径到项目根目录
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.environ['PLAYWRIGHT_BROWSERS_PATH'] = project_root


class DynamicWebScraper:
    """动态网页抓取器（同步版本）"""

    def __init__(self):
        self.playwright = None
        self.browser = None   # 改名为 browser 更清晰

    def _init_driver(self):
        """初始化浏览器驱动（同步）"""
        if self.browser:
            return

        # Windows 下需要设置 Proactor 事件循环策略以支持子进程
        if sys.platform == "win32":
            asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

        try:
            self.playwright = sync_playwright().start()
            self.browser = self.playwright.chromium.launch(
                headless=True,
                args=[
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    '--disable-dev-shm-usage',
                    '--disable-gpu'
                ]
            )
        except ImportError as e:
            raise ImportError(
                f"未安装 Playwright，请运行：\n"
                f"  pip install playwright\n"
                f"  playwright install chromium\n"
                f"\n详细错误: {str(e)}"
            )
        except Exception as e:
            import traceback
            error_detail = traceback.format_exc()
            raise Exception(
                f"浏览器驱动初始化失败\n"
                f"错误: {str(e)}\n"
                f"\n请确保：\n"
                f"1. 已安装 Playwright: pip install playwright\n"
                f"2. 已安装浏览器驱动: playwright install chromium\n"
                f"3. 检查系统是否支持 Chromium\n"
                f"\n详细错误:\n{error_detail}"
            )

    def fetch_page(self, url: str, wait_time: int = 3000) -> str:
        """
        抓取动态网页内容

        Args:
            url: 网页URL
            wait_time: 等待时间（毫秒），默认3秒
        """
        self._init_driver()

        try:
            page = self.browser.new_page()
            page.set_default_timeout(30000)
            page.set_extra_http_headers({
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            })
            page.goto(url, wait_until='domcontentloaded', timeout=30000)
            page.wait_for_timeout(wait_time)
            html_content = page.content()
            page.close()
            return html_content
        except Exception as e:
            import traceback
            error_detail = traceback.format_exc()
            raise Exception(
                f"网页抓取失败\n"
                f"URL: {url}\n"
                f"错误: {str(e)}\n"
                f"\n详细错误:\n{error_detail}"
            )

    def fetch_page_with_screenshot(self, url: str, wait_time: int = 3000) -> Tuple[str, bytes]:
        """抓取动态网页并截图"""
        self._init_driver()

        try:
            page = self.browser.new_page()
            page.set_default_timeout(10000)
            page.goto(url, wait_until='domcontentloaded')
            page.wait_for_timeout(wait_time)
            html_content = page.content()
            screenshot = page.screenshot(full_page=True)
            page.close()
            return html_content, screenshot
        except Exception as e:
            raise Exception(f"网页抓取失败: {str(e)}")

    def extract_form_elements(self, html_content: str) -> List[Dict]:
        """提取表单元素（与原逻辑一致）"""
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html_content, 'html.parser')
        elements = []

        # 提取所有 input 元素，根据 type 分类
        for input_tag in soup.find_all('input'):
            input_type = input_tag.get('type', 'text')
            if input_type in ('text', 'password', 'email', ''):
                text = input_tag.get('placeholder', '') or input_tag.get('value', '')
                elements.append({'type': 'input', 'text': text})
            elif input_type == 'checkbox':
                elements.append({'type': 'checkbox', 'text': ''})
            elif input_type == 'radio':
                text = input_tag.get('value', '')
                elements.append({'type': 'radio', 'text': text})
            elif input_type in ('submit', 'button'):
                text = input_tag.get('value', '') or input_tag.get('placeholder', '')
                elements.append({'type': 'button', 'text': text})

        # 提取文本域
        for textarea_tag in soup.find_all('textarea'):
            text = textarea_tag.get('placeholder', '')
            elements.append({'type': 'textarea', 'text': text})

        # 提取下拉选择框
        for select_tag in soup.find_all('select'):
            first_option = select_tag.find('option')
            text = first_option.get_text(strip=True) if first_option else ''
            elements.append({'type': 'select', 'text': text})

        # 提取按钮
        for button_tag in soup.find_all('button'):
            text = button_tag.get_text(strip=True)
            if text:
                elements.append({'type': 'button', 'text': text})

        # 提取标签
        for label_tag in soup.find_all('label'):
            text = label_tag.get_text(strip=True)
            if text:
                elements.append({'type': 'label', 'text': text})

        return elements

    def close(self):
        """关闭浏览器"""
        if self.browser:
            self.browser.close()
        if self.playwright:
            self.playwright.stop()

    def __enter__(self):
        self._init_driver()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()