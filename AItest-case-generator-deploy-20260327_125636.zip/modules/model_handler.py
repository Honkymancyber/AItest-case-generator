# modules/model_handler.py
import os
import base64
from typing import List, Dict #Optional
from openai import OpenAI
from config import SUPPORTED_MODELS
import json

class ModelHandler:
    """大模型调用处理器"""
    
    def __init__(self, model_name: str, api_key: str):
        self.model_config = next(
            (m for m in SUPPORTED_MODELS if m.name == model_name), 
            SUPPORTED_MODELS[0]
        )
        # 优先使用传入的api_key，否则从环境变量获取
        self.api_key = api_key or os.getenv(self.model_config.api_key_env, "")
        if not self.api_key:
            raise Exception(f"缺少API Key，请设置环境变量 {self.model_config.api_key_env}")

        self.client = OpenAI(
            api_key=self.api_key,
            base_url=self.model_config.api_base,
            timeout=60.0,
            max_retries=3
        )

    # modules/model_handler.py
    def chat(self, messages: List[Dict], **kwargs) -> str:
        """调用模型并返回原始字符串（已做基础清洗，不进行 JSON 解析）"""
        try:
            response = self.client.chat.completions.create(
                model=self.model_config.model_name,
                messages=messages,
                timeout=120,  # 增加超时到120秒
                **kwargs
            )
            #return response.choices[0].message.content
            content = response.choices[0].message.content

            # 清洗可能的 markdown 代码块
            content = content.strip()
            if content.startswith("```json"):
                content = content[7:]
            if content.endswith("```"):
                content = content[:-3]
            content = content.strip()
            # 可选：修复不完整的 JSON（仅补全括号，不解析）
            # 尝试修复不完整的 JSON
            if not content.endswith(']'):
                if content.endswith(','):
                    content = content[:-1]
                content += ']'
            return content # 返回字符串
            # test_cases = json.loads(content)
            # if not isinstance(test_cases, list):
            #     raise ValueError("返回的 JSON 不是数组")
            # return test_cases

        except json.JSONDecodeError as e:
            print(f"JSON 解析失败: {e}")
            print(f"原始响应: {content}")
            # 返回空列表，并可在前端显示错误
            return []
        except Exception as e:
            print(f"生成用例失败: {e}")
            return []

        except Exception as e:
            # 打印详细错误信息
            import traceback
            error_details = traceback.format_exc()
            print(f"详细错误: {error_details}")
            print(f"API Base: {self.model_config.api_base}")
            print(f"Model: {self.model_config.model_name}")

            # 提供更友好的错误提示
            error_str = str(e).lower()
            if 'connection' in error_str or 'timeout' in error_str:
                raise Exception(
                    f"网络连接错误，请检查：\n"
                    f"1. 网络连接是否正常\n"
                    f"2. API 服务地址是否正确: {self.model_config.api_base}\n"
                    f"3. 是否需要使用代理\n"
                    f"\n原始错误: {str(e)}"
                )
            elif '401' in error_str or 'unauthorized' in error_str:
                raise Exception(
                    f"API Key 无效或已过期，请检查：\n"
                    f"1. API Key 是否正确\n"
                    f"2. API Key 是否有足够的权限\n"
                    f"3. API Key 是否已过期\n"
                    f"\n原始错误: {str(e)}"
                )
            elif '429' in error_str or 'rate limit' in error_str:
                raise Exception(
                    f"API 调用频率超限，请稍后再试\n"
                    f"\n原始错误: {str(e)}"
                )
            else:
                raise Exception(f"模型调用失败: {str(e)}")
    
    def analyze_test_points(self, content: str) -> List[str]:
        """分析测试点"""
        prompt = f"""
        请分析以下需求内容，提取所有测试点，以JSON数组格式返回：
        
        需求内容：
        {content}
        
        请返回格式：
        ["测试点1", "测试点2", "测试点3", ...]
        """
        
        messages = [{"role": "user", "content": prompt}]
        response = self.chat(messages)
        
        # 解析JSON响应
        import json
        try:
            test_points = json.loads(response)
            return test_points if isinstance(test_points, list) else []
        except Exception as e:
            print(f"解析测试点失败: {e}\n原始响应: {response}")
            # 降级处理：将整个响应作为单个测试点
            return [response] if response else []
    
    def generate_test_cases(self, test_points: List[str], requirement: str) -> List[Dict]:
        """生成测试用例"""
        prompt = f"""
        请根据以下测试点和需求，生成详细的测试用例。
        
        需求内容：
        {requirement}
        
        测试点：
        {chr(10).join(test_points)}
        
        请按以下JSON格式返回测试用例数组：
        [
            {{
                "序号": 1,
                "编号": "TC001",
                "用例名称": "用例名称",
                "模块": "模块名",
                "类型": "功能测试",
                "前置条件": "前置条件",
                "步骤": "步骤1; 步骤2; 步骤3",
                "测试数据": "测试数据",
                "预期结果": "预期结果",
                "优先级": "P1"
            }}
        ]
        """
        
        #messages = [{"role": "user", "content": prompt}]
        messages = [
            {"role": "system",
             "content": "你是一个专业的高级测试工程师专家。请严格按照用户要求的 JSON 格式输出测试用例，不要添加任何解释、注释或 Markdown 标记，最多生成 20 条用例，确保 JSON 完整。"},
            {"role": "user", "content": prompt}
        ]
        response = self.chat(messages, temperature=0.7)
        import json
        import re
        json_str = response.strip()
        # 移除可能的 Markdown 代码块标记
        json_str = re.sub(r'^```json\s*', '', json_str, flags=re.IGNORECASE)
        json_str = re.sub(r'\s*```$', '', json_str)
        # 如果响应以非 [ 开头，尝试提取第一个 [ 到最后一个 ]
        if not json_str.startswith('['):
            match = re.search(r'(\[.*\])', json_str, re.DOTALL)
            if match:
                json_str = match.group(1)

        try:
            cases = json.loads(json_str)
            if isinstance(cases, list):
                return cases
            else:
                return []
        except json.JSONDecodeError as e:
            # 记录错误响应以便调试
            print(f"JSON 解析失败: {e}\n原始响应: {response}")
            return []
    
    def analyze_image(self, image_file) -> str:
        """分析图片内容（多模态）"""
        if not self.model_config.support_multimodal:
            raise Exception("当前模型不支持图片识别")
        
        # 编码图片
        import base64
        image_bytes = image_file.getvalue()
        base64_image = base64.b64encode(image_bytes).decode('utf-8')
        
        messages = [{
            "role": "user",
            "content": [
                {"type": "text", "text": "请详细描述这张图片中的界面元素、功能模块和交互内容，用于生成测试用例。"},
                {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}}
            ]
        }]
        
        return self.chat(messages)