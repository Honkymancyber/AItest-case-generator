# modules/file_parser.py
from docx import Document
import io

class FileParser:
    """文件解析器"""
    
    def parse_word(self, file) -> str:
        """解析Word文档"""
        try:
            doc = Document(file)
            content = []
            for para in doc.paragraphs:
                if para.text.strip():
                    content.append(para.text)
            return "\n".join(content)
        except Exception as e:
            raise Exception(f"文档解析失败: {str(e)}")
    
    def parse_pdf(self, file) -> str:
        """解析PDF文档（可选扩展）"""
        # 可添加 pdfplumber 或 PyPDF2 支持
        pass