# modules/exporter.py
import pandas as pd
import io
from docx import Document
from docx.shared import Inches

class Exporter:
    """用例导出器"""
    
    def to_excel(self, df: pd.DataFrame) -> bytes:
        """导出为Excel"""
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name='测试用例')
        return output.getvalue()
    
    def to_word(self, df: pd.DataFrame) -> bytes:
        """导出为Word"""
        doc = Document()
        doc.add_heading('测试用例文档', 0)
        
        # 添加表格
        table = doc.add_table(rows=1, cols=len(df.columns))
        table.style = 'Table Grid'
        
        # 表头
        for i, col in enumerate(df.columns):
            table.rows[0].cells[i].text = col
        
        # 数据行
        for _, row in df.iterrows():
            cells = table.add_row().cells
            for i, val in enumerate(row):
                cells[i].text = str(val)
        
        output = io.BytesIO()
        doc.save(output)
        return output.getvalue()
    
    def to_markdown(self, df: pd.DataFrame) -> str:
        """导出为Markdown"""
        return df.to_markdown(index=False)