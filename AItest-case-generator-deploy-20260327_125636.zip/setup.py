from setuptools import setup, find_packages

setup(
    name="AItest-case-generator",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
    "streamlit>=1.28.0",
    "pandas>=2.0.0",
    "openpyxl>=3.1.0",
    "python-docx>=0.8.11",
    "openai>=1.0.0",
    "requests>=2.31.0",
    "beautifulsoup4>=4.12.0",
    "python-dotenv>=1.0.0",
    "playwright>=1.40.0"
    # pdfplumber>=0.10.0
    ],
    include_package_data=True,  # 包含非代码文件（需配合 MANIFEST.in）
)