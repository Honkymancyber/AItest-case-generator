# GitHub 开源上传指南

## 📋 上传前准备清单

在将项目上传到 GitHub 之前，请完成以下检查：

### ✅ 必需文件

- [x] `README.md` - 项目说明文档（已完成）
- [x] `LICENSE` - 开源许可证（MIT，已完成）
- [x] `CONTRIBUTING.md` - 贡献指南（已完成）
- [x] `requirements.txt` - Python 依赖列表
- [x] `.gitignore` - Git 忽略文件配置
- [x] `.env.example` - 环境变量示例

### ⚠️ 安全检查

在提交前，请确认已删除或排除以下文件：

- [x] `.env` - 包含真实的 API Key（已在 .gitignore 中）
- [x] `*.log` - 日志文件
- [x] `__pycache__/` - Python 缓存
- [x] `venv/` - 虚拟环境
- [x] `*.pyc` - 编译文件
- [x] `chromium-*` - 浏览器文件（体积大，建议排除）
- [x] `ffmpeg-*` - 媒体文件（体积大，建议排除）

### 📝 文档检查

- [x] README.md 中的仓库链接已更新为实际地址
- [x] README.md 中的邮箱已替换为真实邮箱
- [x] README.md 中的截图（如需要）
- [x] INSTALL.md 中的步骤经过测试

## 🚀 上传步骤

### 1. 初始化 Git 仓库（如果还没有）

```bash
cd C:\Users\10503\PycharmProjects\LLMgenerate_test_case\myenv\testgen-ai-pro
git init
```

### 2. 检查当前 Git 状态

```bash
git status
```

### 3. 添加文件到暂存区

```bash
# 添加所有文件（会根据 .gitignore 自动排除）
git add .

# 或者选择性添加
git add README.md LICENSE CONTRIBUTING.md INSTALL.md
git add app.py config.py requirements.txt setup.py
git add modules/ utils/ docs/
```

### 4. 提交更改

```bash
git commit -m "feat: 初始化 AI Test Case Generator 项目

- 支持多种输入方式（文本/文档/网页/图片）
- 集成多种大模型（DeepSeek/Qwen/GPT-4V）
- 支持静态和动态网页抓取
- 支持多种导出格式（Excel/Word/Markdown）"
```

### 5. 在 GitHub 创建新仓库

1. 访问 [GitHub](https://github.com/)
2. 点击右上角的 "+" → "New repository"
3. 填写仓库信息：
   - Repository name: `AItest-case-generator`
   - Description: `基于大语言模型的AI测试用例生成工具`
   - Public/Private: 选择 Public（开源项目）
   - 勾选 "Add a README file"（如果还没有 README）
   - 勾选 "Choose a license"（选择 MIT License）
4. 点击 "Create repository"

### 6. 关联远程仓库并推送

```bash
   # 添加远程仓库（替换 YOUR_USERNAME 为你的 GitHub 用户名）
git remote add origin https://github.com/YOUR_USERNAME/AItest-case-generator.git

# 或者使用 SSH（推荐，如果你配置了 SSH 密钥）
git remote add origin git@github.com:YOUR_USERNAME/AItest-case-generator.git

# 推送到远程仓库
git branch -M main
git push -u origin main
```

### 7. 验证上传

访问你的 GitHub 仓库地址，检查：
- 所有文件都已上传
- README 正确显示
- License 正确显示
- 代码可以正常查看

## 🏷️ 添加标签（版本标记）

```bash
# 创建 v1.0.0 标签
git tag -a v1.0.0 -m "AI Test Case Generator v1.0.0 - 首次发布"

# 推送标签到远程
git push origin v1.0.0
```

## 📊 后续维护

### 发布 Release

1. 在 GitHub 仓库页面，点击 "Releases" → "Create a new release"
2. 选择标签（如 v1.0.0）
3. 填写发布说明
4. 上传部署包（可选）
5. 点击 "Publish release"

### 更新依赖

当 `requirements.txt` 更新时：

```bash
git add requirements.txt
git commit -m "chore: 更新依赖版本"
git push
```

### 处理 Issue 和 PR

- 定期查看 GitHub Issues
- 及时回复社区问题
- 审核 Pull Request
- 合并贡献者的代码

## 🔧 GitHub 仓库优化建议

### 1. 添加 Topics（标签）

在仓库页面添加相关标签：
- `ai`
- `test-case-generator`
- `streamlit`
- `llm`
- `python`
- `testing`

### 2. 启用 GitHub Actions

创建 `.github/workflows/python.yml`：

```yaml
name: Python CI

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.8'
    - name: Install dependencies
      run: |
        pip install -r requirements.txt
```

### 3. 添加 GitHub Pages

用于部署项目文档（可选）

### 4. 设置 Security

- 在 Settings → Security 中启用 Dependabot
- 启用代码扫描 alerts
- 设置分支保护规则

## 📞 推广项目

- 在社交媒体分享
- 在相关社区发布（如 Reddit、V2EX）
- 写技术博客介绍
- 提交到 Awesome Python 列表

## ⚠️ 注意事项

1. **不要提交敏感信息**：确保 `.env` 等文件在 `.gitignore` 中
2. **文件大小限制**：单个文件不超过 100MB，使用 Git LFS 管理大文件
3. **提交信息规范**：使用清晰、有意义的提交信息
4. **定期更新**：保持依赖更新，修复安全漏洞

## 🎉 完成！

上传完成后，你的项目就可以被全世界的开发者发现和使用了！

---

如果有任何问题，请参考：
- [GitHub 官方文档](https://docs.github.com/)
- [Git 命令速查](https://git-scm.com/docs)
