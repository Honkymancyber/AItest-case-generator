# 故障排除指南

## 网络连接错误 (Connection error)

### 症状
```
Exception: 模型调用失败: Connection error.
```

### 可能原因

1. **网络连接问题**
   - 网络断开或连接不稳定
   - 防火墙阻止了 API 请求

2. **API 服务地址错误**
   - 配置的 API Base 不正确
   - API 服务暂时不可用

3. **需要代理**
   - 在国内访问某些 API 需要代理

### 解决方案

#### 方案 1: 检查网络连接
```bash
# 测试是否能访问 API
ping api.deepseek.com
# 或
curl https://api.deepseek.com
```

#### 方案 2: 配置代理
在 `.env` 文件中添加：
```bash
# HTTP 代理
HTTP_PROXY=http://your-proxy:port
HTTPS_PROXY=http://your-proxy:port
```

或在代码中设置：
```python
import os
os.environ['HTTP_PROXY'] = 'http://your-proxy:port'
os.environ['HTTPS_PROXY'] = 'http://your-proxy:port'
```

#### 方案 3: 检查 API 配置
确认 `config.py` 中的 API Base 是否正确：
- DeepSeek: `https://api.deepseek.com/v1`
- Qwen: `https://dashscope.aliyuncs.com/compatible-mode/v1`
- OpenAI: `https://api.openai.com/v1`

#### 方案 4: 使用国内服务
推荐使用国内可用的服务：
- DeepSeek (国内直连)
- Qwen (阿里云)

## API Key 无效 (401 Unauthorized)

### 症状
```
Exception: API Key 无效或已过期
```

### 解决方案

1. **检查 API Key 是否正确**
   - 确认没有多余的空格
   - 确认复制完整（通常 40+ 字符）

2. **检查 API Key 是否过期**
   - 登录对应平台查看 Key 状态

3. **检查 API Key 权限**
   - 确认 Key 有调用 API 的权限

## API 调用频率超限 (429 Rate Limit)

### 症状
```
Exception: API 调用频率超限
```

### 解决方案

1. **稍后再试**
   - 等待几秒或几分钟后重试

2. **检查 API 配额**
   - 登录对应平台查看剩余配额

3. **升级服务**
   - 如需更高频率，考虑升级套餐

## 超时错误 (Timeout)

### 症状
```
Exception: 请求超时
```

### 解决方案

1. **增加超时时间**
   代码中已设置为 120 秒，如需更长可修改 `model_handler.py` 中的 `timeout` 参数

2. **检查网络稳定性**
   - 尝试使用有线网络
   - 检查网络带宽

## 其他错误

### JSON 解析失败

**症状**: 生成测试用例时返回空数组

**解决方案**:
- 尝试使用不同的模型
- 简化需求描述
- 检查模型是否支持中文

### 模块导入错误

**症状**: `ModuleNotFoundError: No module named 'xxx'`

**解决方案**:
```bash
pip install -r requirements.txt
```

### 文档解析失败

**症状**: 上传 Word 文档时报错

**解决方案**:
- 确认文件格式为 `.docx`（不支持旧版 `.doc`）
- 确认文件没有损坏
- 尝试另存为新的 `.docx` 文件

## 获取帮助

如果以上方法都无法解决问题，请：
1. 查看控制台输出的详细错误信息
2. 检查日志文件（如果有）
3. 在项目 GitHub Issues 中提交问题

## 推荐配置

### 开发环境推荐
- **模型**: DeepSeek-V3 (国内直连，速度快)
- **网络**: 无需代理
- **超时**: 120 秒

### 生产环境推荐
- **模型**: Qwen-Max 或 GPT-4V
- **网络**: 配置代理
- **超时**: 180 秒
- **重试**: 3 次
